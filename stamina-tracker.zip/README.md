# Stamina Tracker
Track stamina or resin for multiple gacha games like Genshin Impact, Honkai: Star Rail, and more.